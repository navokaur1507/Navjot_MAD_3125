package com.jk.thunder;

import android.app.ActionBar;
import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import static android.view.View.*;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnSubmit;
    TextView txtDOB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);

        txtDOB = (TextView) findViewById(R.id.txtDOB);
        txtDOB.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnSubmit.getId()) {
            EditText edtName = (EditText) findViewById(R.id.edtName);
            EditText edtPhone = (EditText) findViewById(R.id.edtPhone);
            EditText edtEmail = (EditText) findViewById(R.id.edtEmail);
            EditText edtPassword = (EditText) findViewById(R.id.edtPassword);


            String name = edtName.getText().toString();
            String phone = edtPhone.getText().toString();
            String email = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();

            Toast.makeText(this, name + "\n" + phone + "\n" + email + "\n" + password, Toast.LENGTH_SHORT).show();
        } else if (view.getId() == txtDOB.getId()) {
            Calendar calender = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListner, calender.get(Calendar.YEAR), Calendar.MONTH, calender.get(Calendar.DAY_OF_MONTH)).show();
        }

    }

    DatePickerDialog.OnDateSetListener datePickerListner = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            String yy = String.valueOf(year);
            String mm = String.valueOf(month+1);
            String dd = String.valueOf(day);

            if (month < 10) {
                mm = "0" + String.valueOf(month);

            }
            if (day < 10) {
                dd = "0" + dd;

            }

            txtDOB.setText(mm + "-" + dd + "-" + yy + "-");

        }
    };
}

