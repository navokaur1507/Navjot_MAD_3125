package com.example.guneetsinghlamba.sgnparking;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ReportAdapter extends BaseAdapter {


    Context context;
    ArrayList<String> location;
    ArrayList<String> price;
    ArrayList<String> time;


    public ReportAdapter(Context context2, ArrayList<String> location
            , ArrayList<String> price, ArrayList<String> time) {
        this.context = context2;
        this.location = location;
        this.price = price;
        this.time = time;
    }

    @Override
    public int getCount() {
        return location.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        Holder holder;
        LayoutInflater layoutInflater;
        if(view == null) {
            layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.custom,null);
            holder = new Holder();
            holder.Location = (TextView) view.findViewById(R.id.locationID);
            holder.Price = (TextView) view.findViewById(R.id.priceID);
            holder.Time = (TextView) view.findViewById(R.id.timeID);
            view.setTag(holder);
            }
            else {
            holder = (Holder) view.getTag();
        }
        holder.Location.setText("Location: "+location.get(i));
        holder.Price.setText("Fare: "+price.get(i)+"$");
        holder.Time.setText("Time:" +time.get(i)+"hours");
        return  view;
    }
    public  class Holder {
        TextView Location;
        TextView Price;
        TextView Time;

    }



}



