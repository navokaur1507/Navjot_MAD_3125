package com.example.guneetsinghlamba.sgnparking;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;


import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class FinalPay extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {


    String carname;
    String location;
    String price;
    String card;
    String Time;
    Button payBill;
    DBHelper dbHelper;
    SQLiteDatabase SGNParking;
    TextView cardNumber;
    TextView expiryDate;
    TextView cvv;
    String loc;
    String pri;
    String ti;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_pay);
        dbHelper = new DBHelper(this);
        SharedPreferences sp = getSharedPreferences("com.example.guneetsinghlamba.sgnparking", Context.MODE_PRIVATE);
        carname = sp.getString("carname","DataMissing");
        location = sp.getString("location","DataMissing");
        price = String.valueOf(sp.getFloat("price",0));
        Time = sp.getString("Time","DataMissing");

        System.out.println(carname + location + price);
        Spinner spinner = (Spinner) findViewById(R.id.cardSpinner);
        spinner.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        categories.add("Visa");
        categories.add("Debit");
        categories.add("Master");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        payBill = (Button) findViewById(R.id.payBill);
        payBill.setOnClickListener(this);
        cardNumber = (TextView) findViewById(R.id.cardNumber);
        expiryDate = (TextView) findViewById(R.id.expiryDate);
        cvv = (TextView) findViewById(R.id.cvv);

    }

    @Override
    public void onClick(View view) {

        if(view.getId() == payBill.getId())
        {
            insertData();
            display();

        }
            }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        card = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item

    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }



    private void insertData() {


        ContentValues con = new ContentValues(); // insert values into database.
        con.put("CarName",carname);
        con.put("Location",location);
        con.put("Price",price);
        con.put("Time",Time);
        //con.put("PaymentMethod",card);
        con.put("CardNumber",cardNumber.getText().toString());


        try {
            SGNParking = dbHelper.getWritableDatabase();

            SGNParking.insert("PARKING",null,con);
          Toast.makeText(this,"Confirmed",Toast.LENGTH_LONG).show();
            Intent home = new Intent(this, com.example.guneetsinghlamba.sgnparking.home.class);
            startActivity(home);

        }catch (Exception ex) {

            Log.e("InsertUser", ex.getMessage());

        }
        SGNParking.close();
    }


    void display() {
        try {
            SGNParking = dbHelper.getReadableDatabase();
            String columns[] = {"Location","Price","Time"};


            Cursor cursor = SGNParking.query("PARKING", columns, null, null, null, null,null);

            while(cursor.moveToNext()){


                 loc = cursor.getString(cursor.getColumnIndex("Location"));

                 pri = cursor.getString(cursor.getColumnIndex("Price"));
                 ti = cursor.getString(cursor.getColumnIndex("Time"));
                System.out.println(loc+pri+ti);


            }
            SharedPreferences sp = getSharedPreferences("com.example.guneetsinghlamba.sgnparking", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();
            edit.putString("Location",loc);
            edit.putString("Price",pri);
            edit.putString("Time",ti);


        }
        catch(Exception e) {
            Log.e("RegisterActivity",e.getMessage());
        }

    }


    }


