package com.example.guneetsinghlamba.sgnparking;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Loginpage extends AppCompatActivity implements View.OnClickListener {


    Button btnLogin;
    Button btnRegister;
    EditText editUsername;
    EditText editPassword;
    DBHelper dbHelper;
    SQLiteDatabase SGNParking;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);
        btnLogin = (Button) findViewById(R.id.button);
        btnRegister = (Button) findViewById(R.id.button2);
        btnLogin.setOnClickListener(this); // Relate to current view.
        btnRegister.setOnClickListener(this); // Relate to current view.
        editUsername = (EditText) findViewById(R.id.editText);
        editPassword = (EditText) findViewById(R.id.editText2);
        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnLogin.getId()) {
            String uname = editUsername.getText().toString();
            String passwd = editPassword.getText().toString();
            SharedPreferences sp = getSharedPreferences("com.example.guneetsinghlamba.sgnparking", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("useremail",uname);
            edit.commit();

            if(verifyLogin()){
                finish();

                Intent homeIntent = new Intent(this, home.class);
                startActivity(homeIntent);

            }

            else {
                Toast.makeText(this, "Invalid username / password", Toast.LENGTH_SHORT).show(); // Make an alert when Login button is clicked.
            }

            }

        else if (view.getId() == btnRegister.getId()) {

            Toast.makeText(this, "Register Clicekd", Toast.LENGTH_SHORT).show(); // Make an alert when Register button is clicked.
            Intent register = new Intent(this, SignUpActivity.class);
            startActivity(register);
        }
    }
    private boolean verifyLogin() {

        try {

            SGNParking = dbHelper.getReadableDatabase();
            String columns[] = {"Email","Password"};
            Cursor cursor = SGNParking.query("NEWUSERS",columns,"Email = ? AND Password = ?",new String[] {editUsername.getText().toString(), editPassword.getText().toString()},null,null,null);
            if (cursor != null)
            {
                if(cursor.getCount() > 0) {
                    return true;
                }
            }
            return false;
        }
        catch(Exception ex) {
            Log.e("LoginActivity","Something wrong with database");
            return false;
        }
        finally {
            SGNParking.close();
        }

    }
}
